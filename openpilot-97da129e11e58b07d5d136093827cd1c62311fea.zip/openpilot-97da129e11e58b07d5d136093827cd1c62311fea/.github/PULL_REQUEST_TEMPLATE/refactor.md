---
name: Refactor
about: For code refactors
title: ''
labels: 'refactor'
assignees: ''
---

**Description**

<!-- A description of the refactor, including the goals it accomplishes. -->

**Verification**

<!-- Explain how you tested the refactor for regressions. -->
