#!/usr/bin/bash

export PASSIVE="0"
exec ./launch_chffrplus.sh

