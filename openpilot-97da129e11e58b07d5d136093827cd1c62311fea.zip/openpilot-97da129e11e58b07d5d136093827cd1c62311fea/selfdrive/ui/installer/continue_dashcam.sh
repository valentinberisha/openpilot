#!/usr/bin/bash

cd /data/openpilot
exec ./launch_chffrplus.sh
